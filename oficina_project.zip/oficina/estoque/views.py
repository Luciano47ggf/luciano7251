# Views serão implementadas conforme necessidade do frontend
